# Control Tienda y Lubricantes

Proyecto Android basado en la versión HTML suministrada.
Incluye:
- TIENDA y LUBRICANTES
- Inventario y Caja independientes
- Cálculo de totales
- Resumen general
- Título y fecha editables
- Generación mediante el diálogo de impresión Android para guardar/compartir como PDF

Para compilar en un servicio CI Android, use `assembleRelease`.
